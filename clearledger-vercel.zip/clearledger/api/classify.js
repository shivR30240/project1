const https = require('https');

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: 'ANTHROPIC_API_KEY environment variable not set.' });
  }

  try {
    const body = JSON.stringify(req.body);

    const data = await new Promise((resolve, reject) => {
      const options = {
        hostname: 'api.anthropic.com',
        path: '/v1/messages',
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(body),
          'x-api-key': apiKey,
          'anthropic-version': '2023-06-01',
        },
      };

      const proxyReq = https.request(options, (proxyRes) => {
        let raw = '';
        proxyRes.on('data', chunk => raw += chunk);
        proxyRes.on('end', () => resolve({ status: proxyRes.statusCode, body: raw }));
      });

      proxyReq.on('error', reject);
      proxyReq.write(body);
      proxyReq.end();
    });

    res.status(data.status).setHeader('Content-Type', 'application/json').end(data.body);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}
